package com.red.team.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    TextToSpeech t1;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.main_menu);

            final ListView listview = (ListView) findViewById(R.id.main_list);
            String[] values = new String[] { "Get Blinking!", "Calibration", "Settings"};
            final ArrayList<String> list = new ArrayList<String>();
            for (int i = 0; i < values.length; ++i) {
                list.add(values[i]);
            }
            final StableArrayAdapter adapter = new StableArrayAdapter(this,
                    android.R.layout.simple_list_item_1, list);
            listview.setAdapter(adapter);

            t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if(status != TextToSpeech.ERROR){
                        t1.setLanguage(Locale.UK);
                    }
                }
            });

            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                    final String item = (String) parent.getItemAtPosition(position);
                    int blink = 1;
                    switch(item) {
                        case "Get Blinking!":
                            Intent intent = new Intent(MainActivity.this , BlinkActivity.class);
                            startActivity(intent);

                            //if the turn on blink is detected, it would play the audio menu
                            if(blink ==1){
                                String play = "Blink now to control the lights";
                                t1.speak(play,TextToSpeech.QUEUE_FLUSH,null);
                            }
                            break;
                        case "Calibration":
                            break;
                        case "Settings":
                            break;
                    }
                }

            });
        }


}



